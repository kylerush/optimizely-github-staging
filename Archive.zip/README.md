##Optimizely staging preview

This extension does the following:

* Adds a preview link to see your changes on the Optimizely staging domain
* Prevents changes on the master branch

URL of extension: [https://chrome.google.com/webstore/detail/optimizely-staging-previe/ggjbgcloiilaommippglmobfhckfmghf?authuser=1](https://chrome.google.com/webstore/detail/optimizely-staging-previe/ggjbgcloiilaommippglmobfhckfmghf?authuser=1)
